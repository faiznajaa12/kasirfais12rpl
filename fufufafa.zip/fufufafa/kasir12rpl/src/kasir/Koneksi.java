/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kasir;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {
    private static Connection koneksi;

    public static Connection getKoneksi() throws SQLException {
        if (koneksi == null || koneksi.isClosed()) {
            try {
                Class.forName("org.postgresql.Driver");
                koneksi = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/kasir_db", // ganti sesuai DB kamu
                    "postgres", // username
                    "jalu123"      // password
                );
            } catch (ClassNotFoundException e) {
                throw new SQLException("Driver PostgreSQL tidak ditemukan!", e);
            }
        }
        return koneksi;
    }
}
